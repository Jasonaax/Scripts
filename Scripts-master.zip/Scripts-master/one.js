/***********************************************

> 应用名称：One成人的世界一个就够了
> 脚本作者：@ddgksf2013
> 下载地址：https://apps.apple.com/cn/app/id6449183241
> 微信账号：墨鱼手记
> 更新时间：2023-06-05
> 通知频道：https://t.me/ddgksf2021
> 贡献投稿：https://t.me/ddgksf2013_bot
> 问题反馈：ddgksf2013@163.com
> 特别提醒：如需转载请注明出处，谢谢合作！
> 脚本说明：去除开屏广告
> 官网地址：https://one55.app
> 变身秘钥：#iPhone#lIkqON75kCeOXAXCFF1Jrl5JMa//prCbbG3eOFe2Ym3r67kCTflzWbhA0AhXT1Fb7k1RVs5GdTeBbRM4G6TazBdJEO5a1UdKScFnyPqkk5hzkHz3+KKehYG6h2qBItAuNbAg4i1ll+jr6RhXZ6JKHeg0YHXa2yqUPaMzF1f9V1YIEj8OydmlZMcYp5TILWk3zoUdo7f2ea9tAT3k5kgE3TcI3HKlBdu59Uh65f2BBG97woweipZhsR9Y/rBnNIjZw+Lza+fRnLcl9Lr5wsqp5LBd/FYfeMsT7qF9NLGI0XHMeatSCrXpwEFhu9MfBAW9fpieqnEZa+pRH2g/Wymh2P/DW72lVcLJDPFvWZMFp3Dnx+3hp5DPA2wzXObqsyaWEkD9+x2OP4lQZTQ5j85Z2od6zEVgxtAM9FVkfMx/MQActuGUJgXtoKp7Jb43Y0hmuTVme2upxsD+UFCTe8L4V1lmpmslAl7f8HBdgwPDz/e83otnU+VFpbYLbZo+p6mFVRLspybX6R/uV3q5y9ajvQ==#iPhone#
> 使用说明：复制上面的秘钥，打开马甲APP，即可

[rewrite_local]

^https?:\/\/api\.[a-zA-Z0-9-]+\.com\/.*\/ad\/space url reject-200

[mitm]

hostname = api.3h6bljel.com, api.549p0fze.com, api.d154gvlq.com, api.0qda82zu.com,api.fua89ibo.com

***********************************************/
